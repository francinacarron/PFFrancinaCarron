#README

##Proyecto CODERHOUSE

##Tercer entrega

Tercer entrega de CODER que constá del desarrollo de una página web de una florería. 

En esta última entrega previo al proyecto final se trabajó con:

- SASS: Todo el código fue reversionado a este lenguaje. Haciendo uso tanto de mixins como variables.
- SEO: Mediante la utilización de los meta tag, kw y favicon vistos en clase
- Reversión subida correctamente a github, haciendo omisión mediante el gitignore de archivos innecesarios como node_modules.
- Todas las páginas son 100% responsive y las imagenes utilizadas en ella cuenta con el alt definido.

### :tw-2757: :tw-2757: Puntos  a  aclarar  ### :tw-2757: :tw-2757:

- En la segunda pre entrega, donde se aclara que se puede elegir trabajar con bootstrap o flex + grids, se optó por esta última ya que prefiero aprovechar este curso para aprender bien el código puro. 
- Las medidas utilizadas en el media query no son las estándares, ya que me basé en utilizar los valores donde distintos aspectos de la página "se rompían".
- Se arregló el footbar para que tenga la misma funcionalidad independientemente de su medida y se agregaron las descripciones alt a las imagenes.